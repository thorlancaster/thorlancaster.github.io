import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import javax.swing.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class program extends PApplet {

//MLC101237

float globSpeedMod = 3.5f;
boolean playing = false;
boolean readyPop = false;
boolean balivv = false;
float Ftemp = 0;
int temp = 0;
int temp0 = 0;
int temp1 = 0;
int temp2 = 0;
int temp3 = 0;
boolean spritesLoaded = false;
int money = 630;
long notify = 0;
Bloon[] bloons = new Bloon[8192];
Projectile[] projectiles = new Projectile[8192];
Weapon[] weapons = new Weapon[1000];
Pop[] POP = new Pop[8192];
int[]bloonPixels = new int[700000];
int[]weaponPixels = new int[700000];
PImage POPimg;
PImage POP_ALL;
int POPpointer = 0;
int bloonsPointer = 1;
int projectilePointer = 1;
int weaponPointer = 1;
PImage playField;
int MX = 0;
int MY = 154;
int lives = 100;
boolean updatespawnBloonChildren = false;
PImage cancelBuy;
PImage fieldZones;
String[] BLOONZ;
String notifyMessage = "";
String[] messages;
PImage[][] bloonSprites = new PImage[14][16]; // 14 bloons, 16 states
PImage[] descriptions = new PImage[13];
PImage[][] weaponImages = new PImage[12][16];
PImage[] explosion = new PImage[12];
PImage[][] projectileImages = new PImage[12][16];
PImage[] numbers = new PImage[10];

PImage BOMB;
PImage BIG_BOMB;
PImage OBSTACLE;
PImage TACK_POP;

int weaponSelected = 0;
int weaponHovered = 0;
int weaponDragged = 0;
int roundStarted = 1000000;

int round = 0;
int roundFrame = 0;
int BT = 0;
int BLACK;
int WHITE;
int[][] bloonArray = new int[50][10000];
int tempMinDistance = 0;
int tempID = 0;
boolean loaded = false;
boolean preloaderInit = false;
PImage AZMA;
PImage BVWAST;
PImage BABY;
int progress = 0;
float Nhale = 0;
int SDApop = 0;
public void setup()
{
  frame.setTitle("loading...");
  frameRate(35);
  BLACK = color(0, 0, 0);
  WHITE = color(255, 255, 255);
  size(1000, 700);
  frame.setLocation(0, 0);
  money = 1000000000;
  lives = 1000000000;
}
public void draw()
{
  if (!loaded || Nhale < progress-5)
  {
    if (!preloaderInit)
    {
      AZMA = loadImage("resources/AZMA.PNG");
      BVWAST = loadImage("resources/BVWAST.PNG");
      BABY = loadImage("resources/BABY.PNG");
      preloaderInit = true;
      background(0);
      image(AZMA, 0, 300);
      image(BABY, 800, 300);
      textSize(100);
      text("LOADING...", 150, 600);
      thread("preloader");
    }
    loadPixels();
    drawSpritePreload(BVWAST, BLACK, 220 + (int)(Nhale*6), 460, false, 0); 
    if (Nhale < progress)
      Nhale+=((progress-Nhale)/40);
    updatePixels();
    return;
  }
  for (int AS = 0; AS < 1; AS++)
  {
    //    try
    //    {
    spawnBloonChildren();
    if (playing)
    {
      if (bloonArray[round][roundFrame] == 69)
      {
        readyPop = true;
      } else {
        spawnBloon(bloonArray[round][roundFrame]);
        bloonArray[round][roundFrame] = 0; // once it is spawned, it is GONE
      }
    }



    for (int x = 0; x < pixels.length; x++)
      pixels[x] = playField.pixels[x];  // quick copy image to background
    if (weaponHovered != 0)
      drawSpriteSafe(descriptions[weaponHovered], 0, 916, 416, false, 0);
    else if (mouseX > 836 && mouseY < 630 && weaponSelected != 0)
      drawSpriteSafe(cancelBuy, BLACK, 916, 416, false, 0);
    else
      drawSpriteSafe(descriptions[weaponSelected], 0, 916, 416, false, 0);

    for (int x = 0; x < 8192; x++)
    {
      if (projectiles[x].type != 0)
      {
        try 
        {
          if (projectiles[x].type == BOOM)
          {
            drawSpriteSafe(explosion[projectiles[x].step], BLACK, projectiles[x].xPos, projectiles[x].yPos, false, 0);
            if (projectiles[x].step == 2)
              popBloonsBySprite(BOMB, BLACK, projectiles[x].xPos, projectiles[x].yPos, false, 1000);
          } else

            drawSpriteSafe(projectileImages[getFiringType(projectiles[x].type, projectiles[x].level)][projectiles[x].rotation], BLACK, projectiles[x].xPos, projectiles[x].yPos, false, 0);

          if (projectiles[x].xPos < 0 || projectiles[x].xPos > 1000)
            projectiles[x].type = 0;

          projectiles[x].step++;
          projectiles[x].xPos+=projectiles[x].xVel;
          projectiles[x].yPos+=projectiles[x].yVel;

          if (projectiles[x].type == BOOM && projectiles[x].step > 11)
            projectiles[x].type = 0;
          if (projectiles[x].type == TACK && projectiles[x].step > 7)
            projectiles[x].type = 0;
          if (projectiles[x].type == DART && projectiles[x].step > 27)
            projectiles[x].type = 0;
          if (projectiles[x].type == SUPERDART && (projectiles[x].step > 30 || projectiles[x].xPos < 0 || projectiles[x].yPos < 0 || projectiles[x].xPos > 1000 || projectiles[x].yPos > 700))
            projectiles[x].type = 0;
          if (projectiles[x].type == TACK || projectiles[x].type == DART)
          {
            if (popBloonsBySprite(projectileImages[getFiringType(projectiles[x].type, projectiles[x].level)][projectiles[x].rotation], BLACK, projectiles[x].xPos, projectiles[x].yPos, false, 1) > 0)
              projectiles[x].type = 0;
          }
          if (projectiles[x].type == SUPERDART)
          {
            if (popBloonsBySprite(projectileImages[getFiringType(projectiles[x].type, projectiles[x].level)][projectiles[x].rotation], BLACK, projectiles[x].xPos, projectiles[x].yPos, false, 1) > 0)
            {
              projectiles[x].type = 0;
              if (SDApop > 10)
              {
                spawnBloonChildren();
                SDApop = 0;
              }
              SDApop++;
            }
          }
        }
        catch(Exception e) // if the projectile goes off the screen, delete it
        {
          projectiles[x].type = 0;
        }
      }
    }

    for (int x = 0; x < 1000; x++)
    {
      if (weapons[x].type != 0)
      {
        drawSpriteSafe(weaponImages[weapons[x].type - 1][weapons[x].rotation], BLACK, weapons[x].xPos, weapons[x].yPos, false, 0);
        if (weapons[x].type == PINEAPPLE)
        {
          if (weapons[x].step > 59)
          {
            weapons[x].type = 0;
            spawnProjectile(weapons[x].xPos, weapons[x].yPos, 0, 0, BOOM, 0);
          }
          weapons[x].step++;
        } else if (weapons[x].type == ROAD_SPIKES)
        {
          weapons[x].lives -= popBloonsBySprite(OBSTACLE, BLACK, weapons[x].xPos, weapons[x].yPos, true, weapons[x].lives);
          if (weapons[x].lives < 10)
          {
            if (weapons[x].lives > 0)
              drawSpriteSafe(numbers[weapons[x].lives], BLACK, weapons[x].xPos, weapons[x].yPos, false, 0);
          }
          weapons[x].step++;
        } else if (weapons[x].type == TACK_SHOOTER)
        {
          if ((weapons[x].step%40) == 0 && getFiringAngle(weapons[x].xPos, weapons[x].yPos, weapons[x].range(), 0) > -1)
          {
            spawnProjectile(weapons[x].xPos, weapons[x].yPos, -7, -7, TACK, weapons[x].upgrade1);
            spawnProjectile(weapons[x].xPos, weapons[x].yPos, -10, 0, TACK, weapons[x].upgrade1);
            spawnProjectile(weapons[x].xPos, weapons[x].yPos, -7, 7, TACK, weapons[x].upgrade1);
            spawnProjectile(weapons[x].xPos, weapons[x].yPos, 0, 10, TACK, weapons[x].upgrade1);
            spawnProjectile(weapons[x].xPos, weapons[x].yPos, 7, 7, TACK, weapons[x].upgrade1);
            spawnProjectile(weapons[x].xPos, weapons[x].yPos, 7, -7, TACK, weapons[x].upgrade1);
            spawnProjectile(weapons[x].xPos, weapons[x].yPos, 10, 0, TACK, weapons[x].upgrade1);
            spawnProjectile(weapons[x].xPos, weapons[x].yPos, 0, -10, TACK, weapons[x].upgrade1);
          }
          weapons[x].step++;
        } else if (weapons[x].type == MONKEY_GLUE)
        {
          weapons[x].lives -= glueBloonsBySprite(OBSTACLE, BLACK, weapons[x].xPos, weapons[x].yPos, weapons[x].lives);
          weapons[x].step++;
        } else if (weapons[x].type == SUPER_MONKEY)
        {
          Ftemp = getFiringAngle(weapons[x].xPos, weapons[x].yPos, weapons[x].range(), 1);
          //          println((int)sin((Ftemp*TWO_PI)*40));
          if (Ftemp > 0 && (weapons[x].step%2) == 0)
          {
            spawnProjectile(weapons[x].xPos, weapons[x].yPos, (int)(cos(Ftemp*TWO_PI)*35+random(-1, 1)), (int)(sin(Ftemp*TWO_PI)*35+random(-1, 1)), SUPERDART, weapons[x].upgrade1);
            weapons[x].rotation = (int)(Ftemp * 16+4)%16;
          }
          weapons[x].step++;
        } else if (weapons[x].type == DART_MONKEY)
        {
          Ftemp = getFiringAngle(weapons[x].xPos, weapons[x].yPos, weapons[x].range(), 1);
          //          println((int)sin((Ftemp*TWO_PI)*40));
          if (Ftemp > 0 && (weapons[x].step%20) == 0)
          {
            spawnProjectile(weapons[x].xPos, weapons[x].yPos, (int)(cos(Ftemp*TWO_PI)*15+random(-1, 1)), (int)(sin(Ftemp*TWO_PI)*15+random(-1, 1)), DART, 0);
            weapons[x].rotation = (int)(Ftemp * 16+4)%16;
          }
          weapons[x].step++;
        }
        if (weapons[x].lives < 1)
          weapons[x].type = 0;
      }
    }
    for (int x = 0; x < 700000; x++)
      bloonPixels[x] = 0;
    for (int x = 0; x < 8192; x++)
    {
      if (bloons[x].type != 0)
      {
        try 
        {        
          drawSpriteSafe(POP_ALL, BLACK, bloonPath[bloons[x].step], 0, true, x);
          drawSpriteSafe(bloonSprites[bloons[x].type-1][bloons[x].rotation], BLACK, bloonPath[bloons[x].step], 0, false, 0);
        }
        catch(Exception e) // if the bloon went off the screen
        {
        }
        if (bloons[x].step > bloonPath.length)
        {
          lives-=bloons[x].oops();
          bloons[x].type = 0;
        }
      }
      bloons[x].step+=(bloons[x].speed(frameCount)*globSpeedMod)+(int)random(-1.1f, 1.1f);
    }
    for (int x = 0; x < 8192; x++)
    {
      if (POP[x].timeToLive > 0)
      {
        try {
          drawSpriteSafe(POPimg, BLACK, bloonPath[POP[x].position], 0, false, 0);
        }
        catch(Exception e)
        {
        }
        POP[x].timeToLive--;
        POP[x].position+=6;
      }
    }



    if (roundStarted < 1000000)
      roundStarted++;
    //  println(mouseX, " ", mouseY);
    getHover();

    if (mousePressed)
      weaponDragged = weaponSelected;
    else 
    {
      if (mouseX < 812 && weaponDragged != 0 && weaponPlaceable(weaponDragged, mouseX, mouseY))
      {
        if (money >= costs[weaponDragged])
        {
          money -= costs[weaponDragged];
          spawnWeapon(mouseX, mouseY, weaponDragged);
          setWeaponPixelsBySprite(weaponImages[weaponDragged][0], BLACK, mouseX, mouseY, weaponPointer);
          weapons[weaponPointer].upgrade1 = 0;
          if (weaponDragged == ROAD_SPIKES)
            weapons[weaponPointer].lives = 10;
          if (weaponDragged == MONKEY_GLUE)
            weapons[weaponPointer].lives = 20;
          if (weaponDragged != ROAD_SPIKES && weaponDragged != MONKEY_GLUE && weaponDragged != PINEAPPLE)
          {
            //            weaponSelected = 0;
            //            weaponDragged = 0;
          }
          //          println(mouseX+"  "+mouseY+"  "+weaponDragged);
        } else
        {
          notifyMessage = "not enough money";
          notify = 0;
        }
      }
      weaponDragged = 0;
    }

    if (weaponSelected != 0)
      drawSpriteSafe(weaponImages[weaponSelected-1][0], BLACK, mouseX, mouseY, false, 0);

    if (readyPop)
    {
      balivv = true;
      for (int x = 0; x < 8192; x++)
      {
        if (bloons[x].type != 0)
          balivv = false;
      }
      if (balivv)
      {
        readyPop = false;
        playing = false;
        notifyMessage = "round " + round +" Passed " + (round+100)+ " money awarded\n"+messages[round];
        notify = 0;
        println("round passed");
        money+=100;
        money+=round;
        for (int x = 0; x < 1000; x++)
          if (weapons[x].type == ROAD_SPIKES ||weapons[x].type == MONKEY_GLUE)
            weapons[x].type = 0;
      }
    }
    updatePixels();
    if (playing && frameCount%15 == 0)
      roundFrame++;
    if (notify < 100000000)
      notify++;
    fill(191, 255, 255);
    text("Money: " + money +"    lives: "+lives, 10, 20);
    text("Round " + round + " of 50   FPS:" + (int)(frameRate+0.3f), 10, 42);
    fill(255, 0, 0);
    if (notify < 200)
      text(notifyMessage, 10, 64);
    frameCount++;
  }
  frameCount--;
}
public void keyPressed()
{
  if (key == ESC)
  {
    weaponDragged = 0;
    weaponSelected = 0;
    key = 0;
  }
  if (key == CODED)
  {
    if (keyCode == LEFT)
    {
      roundFrame = 0;
    }
    if (keyCode == DOWN)
      for (int x = 0; x < 10000; x++)
        bloonArray[round][x] = 0;
  }
  if (key == 'r')
    spawnBloon(RED_BLOON);
  if (key == 'b')
    spawnBloon(BLUE_BLOON);
  if (key == 'g')
    spawnBloon(GREEN_BLOON);
  if (key == 'y')
    spawnBloon(YELLOW_BLOON);
  if (key == 'p')

    spawnBloon(PINK_BLOON);
  if (key == 'R')
    spawnBloon(RAINBOW_BLOON);
  if (key == 'C')
    spawnBloon(CERAMIC_BLOON);
  if (key == 'B')
    spawnBloon(BLACK_BLOON);
  if (key == 'W')
    spawnBloon(WHITE_BLOON);
  if (key == 'M')
    spawnBloon(MOAB_BLOON);
  if (key == 'L')
    spawnBloon(LEAD_BLOON);
}
public void mousePressed()
{
  if (mouseX > 836 && mouseY < 630 && weaponSelected != 0)
  {
    weaponSelected = 0;
    weaponDragged = 0;
  }
  if (mouseX > 835 && mouseX < 990)
  {
    if (mouseY < 55)
    {
      if (mouseX < 890)
        weaponSelected = TACK_SHOOTER;
      else if (mouseX < 940)
        weaponSelected = BOOMERANG;
      else
        weaponSelected = SPIKE_O_PULT;
    } else if (mouseY < 102)
    {
      if (mouseX < 890)
        weaponSelected = ICE_TOWER;
      else if (mouseX < 940)
        weaponSelected = MONKEY_BEACON;
      else
        weaponSelected = SUPER_MONKEY;
    } else if (mouseY < 152)
    {
      if (mouseX < 890)
        weaponSelected = MONKEY_GLUE;
      else if (mouseX < 940)
        weaponSelected = PINEAPPLE;
      else
        weaponSelected = CLASSIFIED;
    } else if (mouseY < 200)
    {
      if (mouseX < 890)
        weaponSelected = DART_MONKEY;
      else if (mouseX < 940)
        weaponSelected = ROAD_SPIKES;
      else
        weaponSelected = CANNON;
    }
  }
  if (mouseX > 832 && mouseY > 632 && playing == false)
  {
    if (lives > 0)
    {
      playing = true;
      round++;
      roundFrame = 0;
    } else
    {
      JOptionPane.showMessageDialog(null, "You are out of lives./n/nGame Over", "Bloons Tower Defense:", JOptionPane.INFORMATION_MESSAGE);
    }
  }
}

int DS_X = 0;
int DS_Y = 0;
public void drawSprite(PImage IN_X, int clear, int xp, int yp, boolean makeBloony, int bloonID)
{
  DS_X = IN_X.width;
  DS_Y = IN_X.height;
  xp-=(DS_X * 0.5f);
  yp-=(DS_Y * 0.5f); 

  for (int x = 0; x < DS_X; x++)
  {
    for (int y = 0; y < DS_Y; y++)
    {
      if (IN_X.pixels[x+(y*DS_X)] != clear)
      {
        if (makeBloony)
          bloonPixels[(xp+x)+((yp+y)*width)] = bloonID;
        else
          pixels[(xp+x)+((yp+y)*width)] = IN_X.pixels[x+(y*DS_X)];
      }
    }
  }
}
public void drawSpriteSafe(PImage IN_X, int clear, int xp, int yp, boolean makeBloony, int bloonID) // a version of drawSprite that will not raise exceptions
{
  try
  {
    DS_X = IN_X.width;
    DS_Y = IN_X.height;
    xp-=(DS_X * 0.5f);
    yp-=(DS_Y * 0.5f); 

    for (int x = 0; x < DS_X; x++)
    {
      for (int y = 0; y < DS_Y; y++)
      {
        if (makeBloony && (randumb[randex] > 69))
          bloonPixels[(xp+x)+((yp+y)*width)] = bloonID;
        else
          if (IN_X.pixels[x+(y*DS_X)] != clear && ((xp+x)+((yp+y)*width) < 700000) && ((xp+x)+((yp+y)*width) > -1))
          pixels[(xp+x)+((yp+y)*width)] = IN_X.pixels[x+(y*DS_X)];
        randex++;
        if (randex > 696968)
          randex = 0;
      }
    }
  }
  catch(Exception e)
  {
  }
}
public void setWeaponPixelsBySprite(PImage IN_X, int clear, int xp, int yp, int weaponID) // a version of drawSprite that will not raise exceptions
{
  try
  {
    DS_X = IN_X.width;
    DS_Y = IN_X.height;
    xp-=(DS_X * 0.5f);
    yp-=(DS_Y * 0.5f); 

    for (int x = 0; x < DS_X; x++)
    {
      for (int y = 0; y < DS_Y; y++)
      {
        if (IN_X.pixels[x+(y*DS_X)] != clear && ((xp+x)+((yp+y)*width) < 700000) && ((xp+x)+((yp+y)*width) > -1))
          weaponPixels[(xp+x)+((yp+y)*width)] = weaponID;
      }
    }
  }
  catch(Exception e)
  {
  }
}
public void drawSpritePreload(PImage IN_X, int clear, int xp, int yp, boolean makeBloony, int bloonID) // a version of drawSprite that will not raise exceptions
{
  try
  {
    DS_X = IN_X.width;
    DS_Y = IN_X.height;
    xp-=(DS_X * 0.5f);
    yp-=(DS_Y * 0.5f); 

    for (int x = 0; x < DS_X; x++)
    {
      for (int y = 0; y < DS_Y; y++)
      {
        if (IN_X.pixels[x+(y*DS_X)] != clear && ((xp+x)+((yp+y)*width) < 700000) && ((xp+x)+((yp+y)*width) > -1) && bright(IN_X.pixels[x+(y*DS_X)]) >  bright(pixels[(xp+x)+((yp+y)*width)]))
          pixels[(xp+x)+((yp+y)*width)] = IN_X.pixels[x+(y*DS_X)];
        if (makeBloony)
          bloonPixels[(xp+x)+((yp+y)*width)] = bloonID;
      }
    }
  }
  catch(Exception e)
  {
  }
}
public int bright(int in_x)
{
  return (in_x >> 16 & 0xFF)+(in_x >> 8 & 0xFF)+(in_x & 0xFF);
}

public float getFiringAngle(int weapX, int weapY, int range, int accurate)
{ 
  temp2 = -1;
  temp3 = 0;
  for (int x = 0; x < 8192; x++) 
  {
    if (bloons[x].type != 0 && bloons[x].step < bloonPath.length && bloons[x].step > 0)
    {
      temp0 = bloonPath[bloons[x].step] % 1000;
      temp1 = bloonPath[bloons[x].step] / 1000;
      //      println((int)sqrt((weapX-temp0)*(weapX-temp0) + (weapY-temp1)*(weapY-temp1)));
      if ((weapX-temp0)*(weapX-temp0) + (weapY-temp1)*(weapY-temp1) < range*range)
      {
        if (bloons[x].step > temp3)
        {
          temp2 = x;
          temp3 = bloons[x].step;
        }
      }
    }
  }
  if (temp2 >= 0)
  {
    temp0 = bloonPath[temp3] % 1000;
    temp1 = bloonPath[temp3] / 1000;
    if ((weapX-temp0)*(weapX-temp0) + (weapY-temp1)*(weapY-temp1) < range*range)
      return (atan2(weapY-temp1, weapX-temp0) + PI)/TWO_PI;
  }
  return -1;
}

class Pop
{
  int timeToLive = 0;
  int position = 0;
  Pop()
  {
    timeToLive = 0;
    position = 0;
  }
}

int RED_BLOON = 1;
int BLUE_BLOON = 2;
int GREEN_BLOON = 3;
int YELLOW_BLOON = 4;
int PINK_BLOON = 5;
int BLACK_BLOON = 6;
int WHITE_BLOON = 7;
int CAMO_BLOON = 8;
int ZEBRA_BLOON = 9;
int LEAD_BLOON = 10;
int RAINBOW_BLOON = 11;
int CERAMIC_BLOON = 12;
int MOAB_BLOON = 13;
int BFB_BLOON = 14;
float BTSval = 0;
class Bloon
{
  int freezeFrame = 0; // frame in which the bloon will be UNFROZEN
  boolean permaFrost = false;
  boolean gluey = false;
  int step = 0;
  int damage = 0;
  int type = 0;
  int rotation = 0;
  Bloon(int IN_X) // create a new, active bloon at the beginning of specified type and zero damage
  {
    this.step = 16;
    this.damage = 0;
    this.rotation = 0;
    this.type = IN_X;
  }
  public float speed(int gameFrame)
  {
    if (type == RED_BLOON)
      BTSval = 1;
    else if (type == BLUE_BLOON)
      BTSval = 1.4f;
    else if (type == GREEN_BLOON)
      BTSval = 1.8f;
    else if (type == YELLOW_BLOON)
      BTSval = 3.2f;
    else if (type == PINK_BLOON)
      BTSval = 3.5f;
    else if (type == BLACK_BLOON)
      BTSval = 1.8f;
    else if (type == WHITE_BLOON)
      BTSval = 1.4f;
    else if (type == LEAD_BLOON)
      BTSval = 1;
    else if (type == CAMO_BLOON)
      BTSval = 1.4f;
    else if (type == ZEBRA_BLOON)
      BTSval = 1.8f;
    else if (type == RAINBOW_BLOON)
      BTSval = 2.2f;
    else if (type == CERAMIC_BLOON)
      BTSval = 2.5f;
    else
      BTSval = 1;
    if(freezeFrame > gameFrame && (type != WHITE_BLOON))
      return 0;
    if(gluey && type != MOAB_BLOON && type != CERAMIC_BLOON)
      BTSval *= 0.5f;
    if(permaFrost)
      BTSval *= 0.8f;
    return BTSval;
  }
  public int oops()
  {
    if (type == RED_BLOON)
      return 1;
    else if (type == BLUE_BLOON)
      return 2;
    else if (type == GREEN_BLOON)
      return 3;
    else if (type == YELLOW_BLOON)
      return 4;
    else if (type == PINK_BLOON)
      return 5;
    else if (type == BLACK_BLOON)
      return 11;
    else if (type == WHITE_BLOON)
      return 11;
    else if (type == CAMO_BLOON)
      return 9;
    else if (type == ZEBRA_BLOON)
      return 23;
    else if (type == LEAD_BLOON)
      return 23;
    else if (type == RAINBOW_BLOON)
      return 35;
    else if (type == CERAMIC_BLOON)
      return 60;
    return 10000000; // if you let a MOAB or BFB escape, it's game over
  }
}
public void spawnBloon(int IN_X)
{
  bloons[bloonsPointer] = new Bloon(IN_X);
  bloonsPointer++;
  if (bloonsPointer == 8190)
    bloonsPointer = 1;
}
public void spawnBloonChild(int IN_X, int Ix)
{
  bloons[bloonsPointer] = new Bloon(IN_X);
  bloons[bloonsPointer].step = Ix;
  bloonsPointer++;
  if (bloonsPointer == 8190)
    bloonsPointer = 0;
}
public void initializeBloons()
{
  for (int x = 0; x < 8192; x++)
  {
    bloons[x] = new Bloon(0); // fill bloon field with blank bloons
  }
}

int[] cantPop = new int[1024];
int CPP = 0;
public int popBloonsBySprite(PImage IN_X, int clear, int xp, int yp, boolean knock, int maxBloons)
{
  int PCPT = 0;
  PCPT = 0;
  CPP = 0;
  DS_X = IN_X.width;
  DS_Y = IN_X.height;
  xp-=(DS_X * 0.5f);
  yp-=(DS_Y * 0.5f); 
  int CB_ID = 0;
  int CP_ID = 0;
  for (int x = 0; x < DS_X; x++)
  {
    for (int y = 0; y < DS_Y; y++)
    {
      try {
        if ((IN_X.pixels[x+(y*DS_X)] != clear)&&(bloonPixels[(xp+x)+((yp+y)*1000)] != 0))
        {
          PCPT++;
          CB_ID = bloonPixels[(xp+x)+((yp+y)*1000)];
          bloons[CB_ID].damage++;
          money++;
          for (int z = -50; z < 50; z++)
          {
            for (int a = -50; a < 50; a++)
            {
              CP_ID = (bloonPath[bloons[CB_ID].step])+z+(a*1000);
              if (CP_ID < 700000 && bloonPixels[CP_ID] == CB_ID)
                bloonPixels[CP_ID] = 0;
            }
          }


          if (knock)
            bloons[CB_ID].step -= bloons[CB_ID].speed(frameCount)*2*globSpeedMod;
          if (PCPT == maxBloons);
          break;
        }
      }
      catch(Exception e)
      {
      }
    }
  }
  return PCPT;
}
public int glueBloonsBySprite(PImage IN_X, int clear, int xp, int yp, int maxBloons)
{
  int PCPT = 0;
  CPP = 0;
  DS_X = IN_X.width;
  DS_Y = IN_X.height;
  xp-=(DS_X * 0.5f);
  yp-=(DS_Y * 0.5f); 
  int CB_ID = 0;
  int CP_ID = 0;
  for (int x = 0; x < DS_X; x++)
  {
    for (int y = 0; y < DS_Y; y++)
    {
      try {
        if ((IN_X.pixels[x+(y*DS_X)] != clear)&&(bloonPixels[(xp+x)+((yp+y)*1000)] != 0))
        {
          CB_ID = bloonPixels[(xp+x)+((yp+y)*1000)];
          if (!(bloons[CB_ID].gluey))
          {
            bloons[CB_ID].gluey = true;
            PCPT++;
          }
          for (int z = -50; z < 50; z++)
          {
            for (int a = -50; a < 50; a++)
            {
              CP_ID = (bloonPath[bloons[CB_ID].step])+z+(a*1000);
              if (CP_ID < 700000 && bloonPixels[CP_ID] == CB_ID)
                bloonPixels[CP_ID] = 0;
            }
          }


          if (PCPT == maxBloons);
          break;
        }
      }
      catch(Exception e)
      {
      }
    }
  }
  return PCPT;
}

int[] bloonPath = {
  54001, 154002, 154003, 154004, 154005, 154006, 154007, 154008, 154009, 154010, 154011, 154012, 154013, 154014, 154015, 154016, 154017, 154018, 154019, 154020, 154021, 154022, 154023, 154024, 154025, 154026, 154027, 154028, 154029, 154030, 154031, 154032, 154033, 154034, 154035, 154036, 154037, 154038, 154039, 154040, 154041, 154042, 154043, 154044, 154045, 154046, 154047, 154048, 154049, 154050, 154051, 154052, 154053, 154054, 154055, 154056, 154057, 154058, 154059, 154060, 154061, 154062, 154063, 154064, 154065, 154066, 154067, 154068, 154069, 154070, 154071, 154072, 154073, 154074, 154075, 154076, 154077, 154078, 154079, 154080, 154081, 154082, 154083, 154084, 154085, 154086, 154087, 154088, 154089, 154090, 154091, 154092, 154093, 154094, 154095, 154096, 154097, 154098, 154099, 154100, 154101, 154102, 154103, 154104, 154105, 154106, 154107, 154108, 154109, 154110, 154111, 154112, 154113, 154114, 154115, 154116, 154117, 154118, 154119, 154120, 154121, 154122, 154123, 154124, 154125, 154126, 154127, 154128, 154129, 154130, 154131, 154132, 154133, 154134, 154135, 154136, 154137, 154138, 154139, 154140, 154141, 154142, 154143, 154144, 154145, 154146, 154147, 154148, 154149, 154150, 154151, 154152, 154153, 154154, 154155, 154156, 154157, 154158, 154159, 154160, 154161, 154162, 154163, 154164, 154165, 154166, 154167, 154168, 154169, 154170, 154171, 154172, 154173, 154174, 154175, 154176, 154177, 154178, 154179, 154180, 154181, 154182, 154183, 154184, 154185, 154186, 154187, 154188, 154189, 154190, 154191, 154192, 154193, 154194, 154195, 154196, 154197, 154198, 154199, 154200, 154201, 154202, 154203, 154204, 154205, 154206, 154207, 154208, 154209, 154210, 154211, 154212, 154213, 154214, 154215, 154216, 154217, 154218, 154219, 154220, 154221, 154222, 154223, 154224, 154225, 154226, 154227, 154228, 154229, 154230, 154231, 154232, 154233, 154234, 154235, 154236, 154237, 154238, 154239, 154240, 154241, 154242, 154243, 154244, 154245, 154246, 154247, 154248, 154249, 154250, 154251, 154252, 154253, 154254, 154255, 154256, 154257, 154258, 154259, 154260, 154261, 154262, 154263, 154264, 154265, 154266, 154267, 154268, 154269, 154270, 154271, 154272, 154273, 154274, 154275, 154276, 154277, 154278, 154279, 154280, 154281, 154282, 154283, 154284, 154285, 154286, 154287, 154288, 154289, 154290, 154291, 154292, 154293, 154294, 154295, 154296, 154297, 154298, 154299, 154300, 154301, 154302, 154303, 154304, 154305, 154306, 154307, 154308, 154309, 154310, 154311, 154312, 154313, 154314, 154315, 154316, 154317, 154318, 154319, 154320, 154321, 154322, 154323, 154324, 154325, 154326, 154327, 154328, 154329, 154330, 154331, 154332, 154333, 154334, 154335, 154336, 154337, 154338, 154339, 154340, 154341, 154342, 154343, 154344, 154345, 154346, 154347, 154348, 154349, 154350, 154351, 154352, 154353, 154354, 154355, 154356, 154357, 154358, 154359, 154360, 154361, 154362, 154363, 154364, 154365, 154366, 154367, 154368, 154369, 154370, 154371, 154372, 154373, 154374, 154375, 154376, 154377, 154378, 154379, 154380, 154381, 154382, 154383, 154384, 154385, 154386, 154387, 154388, 154389, 154390, 154391, 154392, 154393, 154394, 154395, 154396, 154397, 154398, 154399, 154400, 154401, 154402, 154403, 154404, 154405, 154406, 154407, 154408, 154409, 154410, 154411, 154412, 154413, 154414, 154415, 154416, 154417, 154418, 154419, 154420, 154421, 154422, 154423, 154424, 154425, 154426, 154427, 154428, 154429, 154430, 154431, 154432, 154433, 154434, 154435, 154436, 154437, 154438, 154439, 154440, 154441, 154442, 154443, 154444, 154445, 154446, 154447, 154448, 154449, 154450, 154451, 154452, 154453, 154454, 154455, 154456, 154457, 154458, 154459, 154460, 154461, 154462, 154463, 154464, 154465, 154466, 154467, 154468, 154469, 154470, 154471, 154472, 154473, 154474, 154475, 154476, 154477, 154478, 154479, 154480, 154481, 154482, 154483, 154484, 154485, 154486, 154487, 154488, 154489, 154490, 154491, 154492, 154493, 154494, 154495, 154496, 154497, 154498, 154499, 154500, 154501, 154502, 154503, 154504, 154505, 154506, 154507, 154508, 154509, 154510, 154511, 154512, 154513, 154514, 154515, 154516, 154517, 154518, 154519, 154520, 154521, 154522, 154523, 154524, 154525, 154526, 154527, 154528, 154529, 154530, 154531, 154532, 154533, 154534, 154535, 154536, 154537, 154538, 154539, 154540, 154541, 154542, 154543, 154544, 154545, 154546, 154547, 154548, 154549, 154550, 154551, 154552, 154553, 154554, 154555, 154556, 154557, 154558, 154559, 154560, 154561, 154562, 154563, 154564, 154565, 154566, 154567, 154568, 154569, 154570, 154571, 154572, 154573, 154574, 154575, 154576, 154577, 154578, 154579, 154580, 154581, 154582, 154583, 154584, 154585, 154586, 154587, 154588, 154589, 154590, 154591, 154592, 154593, 154594, 154595, 154596, 154597, 154598, 154599, 154600, 154601, 154602, 154603, 154604, 154605, 154606, 154607, 154608, 154609, 154610, 154611, 154612, 154613, 154614, 154615, 154616, 154617, 154618, 154619, 154620, 154621, 154622, 154623, 154624, 154625, 154626, 154627, 154628, 154629, 154630, 154631, 154632, 154633, 154634, 154635, 154636, 154637, 154638, 154639, 154640, 154641, 154642, 154643, 154644, 154645, 154646, 154647, 154648, 154649, 154650, 154651, 154652, 154653, 154654, 154655, 154656, 154657, 154658, 154659, 154660, 154661, 154662, 154663, 154664, 154665, 154666, 154667, 154668, 154669, 154670, 154671, 154672, 154673, 154674, 154675, 154676, 154677, 154678, 154679, 154680, 154681, 154682, 154683, 154684, 154685, 154686, 154687, 154688, 154689, 154690, 154691, 154692, 154693, 154694, 154695, 154696, 154697, 154698, 154699, 154700, 154701, 154702, 154703, 154704, 154705, 154706, 154707, 154708, 154709, 154710, 154711, 154712, 154713, 154714, 154715, 154716, 154717, 154718, 154719, 154720, 154721, 154722, 154723, 154724, 154725, 154726, 154727, 154728, 154729, 154730, 154731, 154732, 154733, 154734, 154735, 154736, 154737, 154738, 154739, 154740, 154741, 154742, 154743, 154744, 154745, 154746, 154747, 154748, 154749, 154750, 154751, 154752, 154753, 154754, 154755, 154756, 154757, 154758, 154759, 154760, 155760, 155761, 155762, 155763, 155764, 156764, 156765, 157765, 157766, 157767, 157768, 158768, 158769, 159769, 159770, 159771, 160771, 160772, 160773, 161773, 161774, 161775, 162775, 163775, 163776, 164776, 165776, 165777, 166777, 167777, 168777, 169777, 170777, 171777, 172777, 173777, 174777, 175777, 176777, 177777, 178777, 179777, 180777, 181777, 182777, 183777, 184777, 185777, 186777, 187777, 188777, 189777, 190777, 191777, 192777, 193777, 194777, 195777, 196777, 197777, 198777, 199777, 200777, 201777, 202777, 203777, 204777, 205777, 206777, 207777, 208777, 209777, 210777, 211777, 212777, 213777, 214777, 215777, 216777, 217777, 218777, 219777, 220777, 221777, 222777, 223777, 224777, 225777, 226777, 227777, 228777, 229777, 230777, 231777, 232777, 233777, 234777, 235777, 236777, 237777, 238777, 239777, 240777, 241777, 242777, 243777, 244777, 245777, 246777, 247777, 248777, 249777, 250777, 251777, 252777, 253777, 254777, 255777, 256777, 257777, 258777, 259777, 260777, 261777, 262777, 263777, 264777, 265777, 266777, 267777, 268777, 269777, 270777, 271777, 272777, 273777, 274777, 275777, 276777, 277777, 278777, 279777, 280777, 281777, 282777, 283777, 284777, 285777, 286777, 287777, 288777, 289777, 290777, 291777, 292777, 293777, 294777, 295777, 296777, 297777, 298777, 299777, 300777, 301777, 302777, 303777, 304777, 305777, 306777, 307777, 308777, 309777, 310777, 311777, 312777, 313777, 314777, 315777, 316777, 317777, 318777, 319777, 320777, 321777, 322777, 323777, 324777, 325777, 326777, 327777, 328777, 329777, 330777, 331777, 332777, 333777, 334777, 335777, 336777, 337777, 338777, 339777, 340777, 341777, 342777, 343777, 344777, 345777, 346777, 347777, 348777, 349777, 350777, 351777, 352777, 353777, 354777, 355777, 356777, 357777, 358777, 359777, 360777, 361777, 362777, 363777, 364777, 365777, 366777, 367777, 368777, 369777, 370777, 371777, 372777, 373777, 374777, 375777, 376777, 377777, 378777, 379777, 380777, 381777, 382777, 383777, 384777, 385777, 386777, 387777, 388777, 389777, 390777, 391777, 392777, 393777, 394777, 395777, 396777, 397777, 398777, 399777, 400777, 401777, 402777, 403777, 404777, 405777, 406777, 407777, 408777, 409777, 410777, 411777, 412777, 413777, 414777, 415777, 416777, 417777, 418777, 419777, 420777, 421777, 422777, 423777, 424777, 425777, 426777, 427777, 428777, 429777, 430777, 431777, 432777, 433777, 434777, 435777, 436777, 437777, 438777, 439777, 440777, 441777, 442777, 443777, 444777, 445777, 446777, 447777, 448777, 449777, 450777, 451777, 451776, 452776, 453776, 454776, 455776, 456776, 457776, 458776, 459776, 460776, 461776, 462776, 463776, 464776, 465776, 466776, 467776, 468776, 469776, 470776, 471776, 472776, 473776, 474776, 475776, 476776, 477776, 478776, 479776, 480776, 481776, 481775, 482775, 483775, 484775, 485775, 486775, 487775, 488775, 489775, 490775, 491775, 492775, 493775, 494775, 495775, 496775, 496774, 497774, 497773, 497772, 498772, 498771, 499771, 499770, 500770, 500769, 500768, 501768, 501767, 501766, 501765, 501764, 501763, 502763, 502762, 502761, 502760, 502759, 502758, 502757, 502756, 502755, 502754, 502753, 502752, 502751, 502750, 502749, 502748, 502747, 502746, 502745, 502744, 502743, 502742, 502741, 502740, 502739, 502738, 502737, 502736, 502735, 502734, 502733, 502732, 502731, 502730, 502729, 502728, 502727, 502726, 502725, 502724, 502723, 502722, 502721, 502720, 502719, 502718, 502717, 502716, 502715, 502714, 502713, 502712, 502711, 502710, 502709, 502708, 502707, 502706, 502705, 502704, 502703, 502702, 502701, 502700, 502699, 502698, 502697, 502696, 502695, 502694, 502693, 502692, 502691, 502690, 502689, 502688, 502687, 502686, 502685, 502684, 502683, 502682, 502681, 502680, 502679, 502678, 502677, 502676, 502675, 502674, 502673, 502672, 502671, 502670, 502669, 502668, 502667, 502666, 502665, 502664, 502663, 502662, 502661, 502660, 502659, 502658, 502657, 502656, 502655, 502654, 502653, 502652, 502651, 502650, 502649, 502648, 502647, 502646, 502645, 502644, 502643, 502642, 502641, 502640, 502639, 502638, 502637, 502636, 502635, 502634, 502633, 502632, 502631, 502630, 502629, 502628, 502627, 502626, 502625, 502624, 502623, 502622, 502621, 502620, 502619, 502618, 502617, 502616, 502615, 502614, 502613, 502612, 502611, 502610, 502609, 502608, 502607, 502606, 502605, 502604, 502603, 502602, 502601, 502600, 502599, 502598, 502597, 502596, 502595, 502594, 502593, 502592, 502591, 502590, 502589, 502588, 502587, 502586, 502585, 502584, 502583, 502582, 502581, 502580, 502579, 502578, 502577, 502576, 502575, 502574, 502573, 502572, 502571, 502570, 502569, 502568, 502567, 502566, 502565, 502564, 502563, 502562, 502561, 502560, 502559, 502558, 502557, 502556, 502555, 502554, 502553, 502552, 502551, 502550, 502549, 502548, 502547, 502546, 502545, 502544, 502543, 502542, 502541, 502540, 502539, 502538, 502537, 502536, 502535, 502534, 502533, 502532, 502531, 502530, 502529, 502528, 502527, 502526, 502525, 502524, 502523, 502522, 502521, 502520, 502519, 502518, 502517, 502516, 502515, 502514, 502513, 502512, 502511, 502510, 502509, 502508, 502507, 502506, 502505, 502504, 502503, 502502, 502501, 502500, 502499, 502498, 502497, 502496, 502495, 502494, 502493, 502492, 502491, 502490, 502489, 502488, 502487, 502486, 502485, 502484, 502483, 502482, 502481, 502480, 502479, 502478, 502477, 502476, 502475, 502474, 502473, 502472, 502471, 502470, 502469, 502468, 502467, 502466, 502465, 502464, 502463, 502462, 502461, 502460, 502459, 502458, 502457, 502456, 502455, 502454, 502453, 502452, 502451, 502450, 502449, 502448, 502447, 502446, 502445, 502444, 502443, 502442, 502441, 502440, 502439, 502438, 502437, 502436, 502435, 502434, 502433, 502432, 502431, 502430, 502429, 502428, 502427, 502426, 502425, 502424, 502423, 502422, 502421, 502420, 502419, 502418, 502417, 502416, 502415, 502414, 502413, 502412, 502411, 502410, 502409, 502408, 502407, 502406, 502405, 502404, 502403, 502402, 502401, 502400, 502399, 502398, 502397, 502396, 502395, 502394, 502393, 502392, 502391, 502390, 502389, 502388, 502387, 502386, 502385, 502384, 502383, 502382, 502381, 502380, 502379, 502378, 502377, 502376, 502375, 502374, 502373, 502372, 502371, 502370, 502369, 502368, 502367, 502366, 502365, 502364, 502363, 502362, 502361, 502360, 502359, 502358, 502357, 502356, 502355, 502354, 502353, 502352, 502351, 502350, 502349, 502348, 502347, 502346, 502345, 502344, 502343, 502342, 502341, 502340, 502339, 502338, 502337, 502336, 502335, 502334, 502333, 502332, 502331, 502330, 502329, 502328, 502327, 502326, 502325, 502324, 502323, 502322, 502321, 502320, 502319, 502318, 502317, 502316, 502315, 502314, 502313, 502312, 502311, 502310, 502309, 502308, 502307, 502306, 502305, 502304, 502303, 502302, 502301, 502300, 502299, 502298, 502297, 502296, 502295, 502294, 502293, 502292, 502291, 502290, 502289, 502288, 502287, 502286, 502285, 502284, 502283, 502282, 502281, 502280, 502279, 502278, 502277, 502276, 502275, 502274, 502273, 502272, 502271, 502270, 502269, 502268, 502267, 502266, 502265, 502264, 502263, 502262, 502261, 502260, 502259, 502258, 502257, 502256, 502255, 502254, 502253, 502252, 502251, 502250, 502249, 502248, 502247, 502246, 502245, 502244, 502243, 502242, 502241, 502240, 502239, 502238, 502237, 502236, 502235, 502234, 502233, 502232, 502231, 502230, 502229, 502228, 502227, 502226, 502225, 502224, 502223, 502222, 502221, 502220, 502219, 502218, 502217, 502216, 502215, 502214, 502213, 502212, 502211, 502210, 502209, 502208, 502207, 502206, 502205, 502204, 502203, 502202, 502201, 502200, 502199, 502198, 502197, 502196, 502195, 502194, 502193, 502192, 502191, 502190, 502189, 502188, 502187, 502186, 502185, 502184, 502183, 502182, 501182, 501181, 500181, 499181, 499180, 498180, 497180, 497179, 496179, 495179, 494179, 493179, 492179, 491179, 490179, 489179, 488179, 487179, 486179, 485179, 484179, 483179, 482179, 481179, 480179, 479179, 478179, 477179, 476179, 475179, 474179, 473179, 472179, 471179, 470179, 469179, 468179, 467179, 466179, 465179, 464179, 463179, 462179, 461179, 460179, 459179, 458179, 457179, 456179, 455179, 454179, 453179, 452179, 451179, 450179, 449179, 448179, 447179, 446179, 445179, 444179, 443179, 442179, 441179, 440179, 439179, 438179, 437179, 436179, 435179, 434179, 433179, 432179, 431179, 430179, 429179, 428179, 427179, 426179, 425179, 424179, 423179, 422179, 421179, 420179, 419179, 418179, 417179, 416179, 415179, 414179, 413179, 412179, 411179, 410179, 409179, 408179, 407179, 406179, 405179, 404179, 403179, 402179, 401179, 400179, 399179, 398179, 397179, 396179, 395179, 394179, 393179, 392179, 391179, 390179, 389179, 388179, 387179, 386179, 385179, 384179, 383179, 382179, 381179, 380179, 379179, 378179, 377179, 376179, 375179, 374179, 373179, 372179, 371179, 370179, 369179, 368179, 367179, 366179, 365179, 364179, 363179, 362179, 362180, 361180, 360180, 359180, 358180, 357180, 356180, 355180, 354180, 353180, 352180, 351180, 351181, 350181, 349181, 348181, 347181, 346181, 345181, 344181, 343181, 342181, 341181, 340181, 340182, 339182, 338182, 337182, 337183, 336183, 335183, 334183, 333183, 333184, 332184, 331184, 331185, 330185, 329185, 329186, 328186, 327186, 327187, 327188, 327189, 326189, 326190, 326191, 326192, 326193, 326194, 326195, 326196, 326197, 326198, 326199, 326200, 326201, 326202, 326203, 326204, 326205, 326206, 326207, 326208, 326209, 326210, 326211, 326212, 326213, 326214, 326215, 326216, 326217, 326218, 326219, 326220, 326221, 326222, 326223, 326224, 326225, 326226, 326227, 325227, 325228, 325229, 325230, 325231, 325232, 325233, 325234, 325235, 325236, 325237, 325238, 325239, 325240, 325241, 325242, 325243, 325244, 325245, 325246, 325247, 325248, 325249, 325250, 325251, 325252, 325253, 325254, 325255, 325256, 325257, 325258, 325259, 325260, 325261, 325262, 325263, 325264, 325265, 325266, 325267, 325268, 325269, 325270, 325271, 325272, 325273, 325274, 325275, 325276, 325277, 325278, 325279, 325280, 325281, 325282, 325283, 325284, 325285, 325286, 325287, 325288, 325289, 325290, 325291, 325292, 325293, 325294, 325295, 325296, 325297, 325298, 325299, 325300, 325301, 325302, 325303, 325304, 325305, 325306, 325307, 325308, 325309, 325310, 325311, 325312, 325313, 325314, 325315, 325316, 325317, 325318, 325319, 325320, 325321, 325322, 325323, 325324, 325325, 325326, 325327, 325328, 325329, 325330, 325331, 325332, 325333, 325334, 325335, 325336, 325337, 325338, 325339, 325340, 325341, 325342, 325343, 325344, 325345, 325346, 325347, 325348, 325349, 325350, 325351, 325352, 325353, 325354, 325355, 325356, 325357, 325358, 325359, 325360, 325361, 325362, 325363, 325364, 325365, 325366, 325367, 325368, 325369, 325370, 325371, 325372, 325373, 325374, 325375, 325376, 325377, 325378, 325379, 325380, 325381, 325382, 325383, 325384, 325385, 325386, 325387, 325388, 325389, 325390, 325391, 325392, 325393, 325394, 325395, 325396, 325397, 325398, 325399, 325400, 325401, 325402, 325403, 325404, 325405, 325406, 325407, 325408, 325409, 325410, 325411, 325412, 325413, 325414, 325415, 325416, 325417, 325418, 325419, 325420, 325421, 325422, 325423, 325424, 325425, 325426, 325427, 325428, 325429, 325430, 325431, 325432, 325433, 325434, 325435, 325436, 325437, 325438, 325439, 325440, 325441, 325442, 325443, 325444, 325445, 325446, 325447, 325448, 325449, 325450, 325451, 325452, 325453, 325454, 325455, 325456, 325457, 325458, 325459, 325460, 325461, 325462, 325463, 325464, 325465, 325466, 325467, 325468, 325469, 325470, 325471, 325472, 325473, 325474, 325475, 325476, 325477, 325478, 325479, 325480, 325481, 325482, 325483, 325484, 325485, 325486, 325487, 325488, 325489, 325490, 325491, 325492, 325493, 325494, 325495, 325496, 325497, 325498, 325499, 325500, 325501, 325502, 325503, 325504, 325505, 325506, 325507, 325508, 325509, 325510, 325511, 325512, 325513, 325514, 325515, 325516, 325517, 325518, 325519, 325520, 325521, 325522, 325523, 325524, 325525, 325526, 325527, 325528, 325529, 325530, 325531, 325532, 325533, 325534, 325535, 325536, 325537, 325538, 325539, 325540, 325541, 325542, 325543, 325544, 325545, 325546, 325547, 325548, 325549, 325550, 325551, 325552, 325553, 325554, 325555, 325556, 325557, 325558, 325559, 325560, 325561, 325562, 325563, 325564, 325565, 325566, 325567, 325568, 325569, 325570, 325571, 325572, 325573, 325574, 325575, 325576, 325577, 325578, 325579, 325580, 325581, 325582, 325583, 325584, 325585, 325586, 325587, 325588, 325589, 325590, 325591, 325592, 325593, 325594, 325595, 325596, 325597, 325598, 325599, 324599, 323599, 323600, 322600, 322601, 321601, 321602, 320602, 320603, 319603, 319604, 318604, 318605, 317605, 317606, 316606, 316607, 315607, 315608, 314608, 314609, 314610, 313610, 313611, 312611, 312612, 311612, 310612, 309612, 308612, 307612, 306612, 305612, 304612, 303612, 302612, 301612, 300612, 299612, 298612, 297612, 296612, 295612, 294612, 293612, 292612, 291612, 291611, 290611, 289611, 288611, 287611, 286611, 285611, 284611, 283611, 282611, 282610, 281610, 280610, 279610, 278610, 277610, 276610, 276609, 275609, 274609, 273609, 272609, 272608, 271608, 270608, 269608, 268608, 268607, 268606, 267606, 266606, 265606, 265605, 265604, 265603, 264603, 264602, 264601, 264600, 264599, 263599, 263598, 263597, 263596, 263595, 263594, 262594, 262593, 262592, 262591, 262590, 261590, 261589, 261588, 261587, 261586, 261585, 261584, 261583, 261582, 261581, 261580, 261579, 261578, 261577, 261576, 261575, 261574, 261573, 261572, 261571, 261570, 261569, 261568, 261567, 261566, 261565, 261564, 261563, 261562, 261561, 261560, 261559, 261558, 261557, 261556, 261555, 261554, 261553, 261552, 261551, 261550, 261549, 261548, 261547, 261546, 261545, 261544, 261543, 261542, 261541, 261540, 261539, 261538, 261537, 261536, 261535, 261534, 261533, 261532, 261531, 261530, 261529, 261528, 261527, 261526, 261525, 261524, 261523, 261522, 261521, 261520, 261519, 261518, 261517, 261516, 261515, 261514, 261513, 261512, 261511, 261510, 261509, 261508, 261507, 261506, 261505, 261504, 261503, 261502, 261501, 261500, 261499, 261498, 261497, 261496, 261495, 261494, 261493, 261492, 261491, 261490, 261489, 261488, 261487, 261486, 261485, 261484, 261483, 261482, 261481, 261480, 261479, 261478, 261477, 261476, 261475, 261474, 261473, 261472, 261471, 261470, 261469, 261468, 261467, 261466, 261465, 261464, 261463, 261462, 261461, 261460, 261459, 261458, 261457, 261456, 261455, 261454, 261453, 261452, 261451, 261450, 261449, 261448, 261447, 261446, 261445, 261444, 261443, 261442, 261441, 261440, 261439, 261438, 261437, 261436, 261435, 261434, 261433, 261432, 261431, 261430, 261429, 261428, 261427, 261426, 261425, 261424, 261423, 261422, 261421, 261420, 261419, 261418, 261417, 261416, 261415, 261414, 261413, 261412, 261411, 261410, 261409, 261408, 261407, 261406, 261405, 261404, 261403, 261402, 261401, 261400, 261399, 261398, 261397, 261396, 261395, 261394, 261393, 261392, 261391, 261390, 261389, 261388, 261387, 261386, 261385, 261384, 261383, 261382, 261381, 261380, 261379, 261378, 261377, 261376, 261375, 261374, 261373, 261372, 261371, 261370, 261369, 261368, 261367, 261366, 261365, 261364, 261363, 261362, 261361, 261360, 261359, 261358, 261357, 261356, 261355, 261354, 261353, 261352, 261351, 261350, 261349, 261348, 261347, 261346, 261345, 261344, 261343, 261342, 261341, 261340, 261339, 261338, 261337, 261336, 261335, 261334, 261333, 261332, 261331, 261330, 261329, 261328, 261327, 261326, 261325, 261324, 261323, 261322, 261321, 261320, 261319, 261318, 261317, 261316, 261315, 261314, 261313, 261312, 261311, 261310, 261309, 261308, 261307, 261306, 261305, 261304, 261303, 261302, 261301, 261300, 261299, 261298, 261297, 261296, 261295, 261294, 261293, 261292, 261291, 261290, 261289, 261288, 261287, 261286, 261285, 261284, 261283, 261282, 261281, 261280, 261279, 261278, 261277, 261276, 261275, 261274, 261273, 261272, 261271, 261270, 261269, 261268, 261267, 261266, 261265, 261264, 261263, 261262, 261261, 261260, 261259, 261258, 261257, 261256, 261255, 261254, 261253, 261252, 261251, 261250, 261249, 261248, 261247, 261246, 261245, 261244, 261243, 261242, 261241, 261240, 261239, 261238, 261237, 261236, 261235, 261234, 261233, 261232, 261231, 261230, 261229, 261228, 261227, 261226, 261225, 261224, 261223, 261222, 261221, 261220, 261219, 261218, 261217, 261216, 261215, 261214, 261213, 261212, 261211, 261210, 261209, 261208, 261207, 261206, 261205, 261204, 261203, 261202, 261201, 261200, 261199, 261198, 261197, 261196, 261195, 261194, 261193, 261192, 261191, 261190, 261189, 261188, 261187, 261186, 261185, 261184, 261183, 261182, 261181, 261180, 261179, 261178, 261177, 261176, 261175, 261174, 261173, 261172, 261171, 261170, 261169, 261168, 261167, 261166, 261165, 261164, 261163, 261162, 261161, 261160, 261159, 261158, 261157, 261156, 261155, 261154, 261153, 261152, 261151, 261150, 261149, 261148, 261147, 261146, 261145, 261144, 261143, 261142, 261141, 261140, 261139, 261138, 261137, 261136, 261135, 261134, 261133, 261132, 261131, 261130, 261129, 261128, 261127, 261126, 261125, 261124, 261123, 261122, 261121, 261120, 261119, 261118, 261117, 261116, 261115, 261114, 261113, 261112, 261111, 261110, 261109, 261108, 261107, 261106, 261105, 261104, 261103, 261102, 261101, 261100, 261099, 261098, 261097, 261096, 261095, 261094, 261093, 261092, 261091, 261090, 261089, 261088, 261087, 261086, 261085, 261084, 261083, 261082, 261081, 261080, 261079, 261078, 261077, 261076, 261075, 261074, 261073, 261072, 261071, 261070, 261069, 261068, 261067, 261066, 261065, 261064, 261063, 261062, 261061, 261060, 261059, 261058, 261057, 261056, 261055, 261054, 262054, 262053, 262052, 262051, 262050, 262049, 262048, 262047, 262046, 263046, 263045, 263044, 263043, 263042, 263041, 263040, 264040, 264039, 264038, 264037, 264036, 265036, 265035, 265034, 265033, 265032, 265031, 265030, 265029, 265028, 266028, 266027, 266026, 266025, 266024, 267024, 267023, 267022, 268022, 269022, 270022, 270021, 271021, 272021, 273021, 274021, 275021, 276021, 277021, 278021, 279021, 280021, 281021, 282021, 283021, 284021, 285021, 286021, 287021, 288021, 289021, 290021, 291021, 292021, 293021, 294021, 295021, 296021, 297021, 298021, 299021, 300021, 301021, 302021, 303021, 304021, 305021, 306021, 307021, 308021, 309021, 310021, 311021, 312021, 313021, 314021, 315021, 316021, 317021, 318021, 319021, 320021, 321021, 322021, 323021, 324021, 325021, 326021, 327021, 328021, 329021, 330021, 331021, 332021, 333021, 334021, 335021, 336021, 337021, 338021, 339021, 340021, 341021, 342021, 343021, 344021, 345021, 346021, 347021, 348021, 349021, 350021, 351021, 352021, 353021, 354021, 355021, 356021, 357021, 358021, 359021, 360021, 361021, 362021, 363021, 364021, 365021, 366021, 367021, 368021, 369021, 370021, 371021, 372021, 373021, 374021, 375021, 376021, 377021, 378021, 379021, 380021, 381021, 382021, 383021, 384021, 385021, 386021, 387021, 388021, 389021, 390021, 391021, 392021, 393021, 394021, 395021, 396021, 397021, 398021, 399021, 400021, 401021, 402021, 403021, 404021, 405021, 406021, 407021, 408021, 409021, 410021, 411021, 412021, 413021, 414021, 415021, 416021, 417021, 418021, 419021, 420021, 421021, 422021, 423021, 424021, 425021, 426021, 427021, 428021, 429021, 430021, 431021, 432021, 433021, 434021, 435021, 436021, 437021, 438021, 439021, 440021, 441021, 442021, 443021, 444021, 445021, 446021, 447021, 448021, 449021, 450021, 451021, 452021, 453021, 454021, 455021, 456021, 457021, 458021, 459021, 460021, 461021, 462021, 463021, 464021, 465021, 466021, 467021, 468021, 469021, 470021, 471021, 472021, 473021, 474021, 475021, 476021, 477021, 478021, 479021, 480021, 481021, 482021, 483021, 484021, 485021, 486021, 487021, 488021, 489021, 490021, 491021, 492021, 493021, 494021, 495021, 496021, 497021, 498021, 499021, 500021, 501021, 502021, 503021, 504021, 505021, 506021, 507021, 508021, 509021, 510021, 511021, 512021, 513021, 514021, 515021, 516021, 517021, 518021, 519021, 520021, 521021, 522021, 523021, 524021, 525021, 526021, 527021, 528021, 529021, 530021, 531021, 532021, 533021, 534021, 535021, 536021, 537021, 538021, 539021, 540021, 541021, 542021, 543021, 544021, 545021, 546021, 547021, 548021, 549021, 550021, 551021, 552021, 553021, 554021, 555021, 556021, 557021, 558021, 559021, 560021, 561021, 562021, 563021, 564021, 565021, 566021, 567021, 568021, 569021, 570021, 571021, 572021, 573021, 574021, 575021, 576021, 577021, 578021, 579021, 580021, 581021, 582021, 583021, 584021, 585021, 586021, 587021, 588021, 589021, 590021, 591021, 592021, 593021, 594021, 595021, 596021, 597021, 598021, 599021, 600021, 601021, 601022, 602022, 603022, 603023, 604023, 605023, 606023, 606024, 607024, 608024, 609024, 609025, 610025, 611025, 611026, 612026, 613026, 614026, 614027, 615027, 616027, 617027, 617028, 618028, 619028, 620028, 620029, 620030, 621030, 621031, 621032, 622032, 622033, 622034, 622035, 622036, 622037, 622038, 622039, 622040, 622041, 622042, 622043, 622044, 622045, 622046, 622047, 622048, 622049, 622050, 622051, 622052, 622053, 622054, 622055, 622056, 622057, 622058, 622059, 622060, 622061, 622062, 622063, 622064, 622065, 622066, 622067, 622068, 623068, 623069, 623070, 623071, 623072, 623073, 623074, 623075, 623076, 623077, 623078, 623079, 623080, 623081, 623082, 623083, 623084, 623085, 623086, 623087, 623088, 623089, 623090, 623091, 623092, 623093, 623094, 623095, 623096, 623097, 623098, 623099, 623100, 623101, 624101, 624102, 624103, 624104, 624105, 624106, 624107, 624108, 624109, 624110, 624111, 624112, 624113, 624114, 624115, 624116, 624117, 624118, 624119, 624120, 624121, 624122, 624123, 624124, 624125, 624126, 624127, 624128, 624129, 624130, 624131, 624132, 624133, 624134, 624135, 624136, 624137, 624138, 624139, 624140, 624141, 624142, 624143, 624144, 624145, 624146, 624147, 624148, 624149, 624150, 624151, 624152, 624153, 624154, 624155, 624156, 624157, 624158, 624159, 624160, 624161, 624162, 624163, 624164, 624165, 624166, 624167, 624168, 624169, 624170, 624171, 624172, 624173, 624174, 624175, 624176, 624177, 624178, 624179, 624180, 624181, 624182, 624183, 624184, 624185, 624186, 624187, 624188, 624189, 624190, 624191, 624192, 624193, 624194, 624195, 624196, 624197, 624198, 624199, 624200, 624201, 624202, 624203, 624204, 624205, 624206, 624207, 624208, 624209, 624210, 624211, 624212, 624213, 624214, 624215, 624216, 624217, 624218, 624219, 624220, 624221, 624222, 624223, 624224, 624225, 624226, 624227, 624228, 624229, 624230, 624231, 624232, 624233, 624234, 624235, 624236, 624237, 624238, 624239, 624240, 624241, 624242, 624243, 624244, 624245, 624246, 624247, 624248, 624249, 624250, 624251, 624252, 624253, 624254, 624255, 624256, 624257, 624258, 624259, 624260, 624261, 624262, 624263, 624264, 624265, 624266, 624267, 624268, 624269, 624270, 624271, 624272, 624273, 624274, 624275, 624276, 624277, 624278, 624279, 624280, 624281, 624282, 624283, 624284, 624285, 624286, 624287, 624288, 624289, 624290, 624291, 624292, 624293, 624294, 624295, 624296, 624297, 624298, 624299, 624300, 624301, 624302, 624303, 624304, 624305, 624306, 624307, 624308, 624309, 624310, 624311, 624312, 624313, 624314, 624315, 624316, 624317, 624318, 624319, 624320, 624321, 624322, 624323, 624324, 624325, 624326, 624327, 624328, 624329, 624330, 624331, 624332, 624333, 624334, 624335, 624336, 624337, 624338, 624339, 624340, 624341, 624342, 624343, 624344, 624345, 624346, 624347, 624348, 624349, 624350, 624351, 624352, 624353, 624354, 624355, 624356, 624357, 624358, 624359, 624360, 624361, 624362, 624363, 624364, 624365, 624366, 624367, 624368, 624369, 624370, 624371, 624372, 624373, 624374, 624375, 624376, 624377, 624378, 624379, 624380, 624381, 624382, 624383, 624384, 624385, 624386, 624387, 624388, 624389, 624390, 624391, 624392, 624393, 624394, 624395, 624396, 624397, 624398, 624399, 624400, 624401, 624402, 624403, 624404, 624405, 624406, 624407, 624408, 624409, 624410, 624411, 624412, 624413, 624414, 624415, 624416, 624417, 624418, 624419, 624420, 624421, 624422, 624423, 624424, 624425, 624426, 624427, 624428, 624429, 624430, 624431, 624432, 624433, 624434, 624435, 624436, 624437, 624438, 624439, 624440, 624441, 624442, 624443, 624444, 624445, 624446, 624447, 624448, 624449, 624450, 624451, 624452, 624453, 624454, 624455, 624456, 624457, 624458, 624459, 624460, 624461, 624462, 624463, 624464, 624465, 624466, 624467, 624468, 624469, 624470, 624471, 624472, 624473, 624474, 624475, 624476, 624477, 624478, 624479, 624480, 624481, 624482, 624483, 624484, 624485, 624486, 624487, 624488, 624489, 624490, 624491, 624492, 624493, 624494, 624495, 624496, 624497, 624498, 624499, 624500, 624501, 624502, 624503, 624504, 624505, 624506, 624507, 624508, 624509, 624510, 624511, 624512, 624513, 624514, 624515, 624516, 624517, 624518, 624519, 624520, 624521, 624522, 624523, 624524, 624525, 624526, 624527, 624528, 624529, 624530, 624531, 624532, 624533, 624534, 624535, 624536, 624537, 624538, 624539, 624540, 624541, 624542, 624543, 624544, 624545, 624546, 624547, 624548, 624549, 624550, 624551, 624552, 624553, 624554, 624555, 624556, 624557, 624558, 624559, 624560, 624561, 624562, 624563, 624564, 624565, 624566, 624567, 624568, 624569, 624570, 624571, 624572, 624573, 624574, 624575, 624576, 624577, 624578, 624579, 624580, 624581, 624582, 624583, 624584, 624585, 624586, 624587, 624588, 624589, 624590, 624591, 624592, 624593, 624594, 624595, 624596, 624597, 624598, 624599, 624600, 624601, 624602, 624603, 624604, 624605, 624606, 624607, 624608, 624609, 624610, 624611, 624612, 624613, 624614, 624615, 624616, 624617, 624618, 624619, 624620, 624621, 624622, 624623, 624624, 624625, 624626, 624627, 624628, 624629, 624630, 624631, 624632, 624633, 624634, 624635, 624636, 624637, 624638, 624639, 624640, 624641, 624642, 624643, 624644, 624645, 624646, 624647, 624648, 624649, 624650, 624651, 624652, 624653, 624654, 624655, 624656, 624657, 624658, 624659, 624660, 624661, 624662, 624663, 624664, 624665, 624666, 624667, 624668, 624669, 624670, 624671, 624672, 624673, 624674, 624675, 624676, 624677, 624678, 624679, 624680, 624681, 624682, 624683, 624684, 624685, 624686, 624687, 625687, 625688, 625689, 626689, 627689, 627690, 627691, 627692, 627693, 628693, 628694, 628695, 628696, 629696, 629697, 629698, 630698, 630699, 631699, 631700, 632700, 632701, 633701, 634701, 635701, 636701, 637701, 638701, 639701, 640701, 641701, 642701, 643701, 644701, 645701, 646701, 647701, 648701, 649701, 650701, 650700, 650699, 650698, 650697, 650696, 650695, 650694, 650693, 650692, 651692, 652692, 653692, 654692, 655692, 656692, 657692, 658692, 659692, 660692, 661692, 662692, 663692, 664692, 665692, 666692, 667692, 668692, 669692, 670692, 671692, 671693, 671694, 671695, 671696, 671697, 671698, 671699, 671700, 671701, 671702, 671703, 671704, 671705, 671706, 671707, 671708, 672708, 673708, 674708, 675708, 676708, 677708, 678708, 679708, 680708, 680707, 680706, 680705, 680704, 680703, 680702, 680701, 680700, 680699, 681699, 682699, 683699, 684699, 685699, 686699, 687699, 687700, 687701, 687702, 688702, 689702, 690702, 691702, 692702, 693702, 694702, 695702, 696702, 697702, 698702, 699702, 700702, 701702, 702702, 703702, 704702, 705702, 706702, 707702, 708702, 709702, 710702, 711702, 712702, 713702, 714702, 715702, 716702, 717702, 718702, 719702, 720702, 721702, 722702, 723702, 724072, 725072, 727072, 727072, 728072, 729072
};
int[] damageThreshold = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 99, 999
};

int[] costs = {
  0, 305, 440, 510, 360, 850, 3200, 30, 20, 100000000, 215, 20, 615
};
PImage imageOut;
int[] randumb = new int[696969];
int randex = 0;
public void loadSprites()
{
  for (int x = 0; x < 12; x++)
  {
    bloonSprites[x][0] = loadImage("resources/sprites/bloons/"+x+".PNG");
    for (int y = 0; y < 16; y++)
    {
      if (y > 0)
        bloonSprites[x][y] = bloonSprites[x][y-1];
      bloonSprites[x][y].loadPixels();
    }
  }
  for (int x = 0; x < 12; x++)
  {
    descriptions[x+1] = loadImage("resources/UIcomponents/descriptions/"+x+".PNG");
    descriptions[x+1].loadPixels();
  }
  for (int x = 0; x < 12; x++)
  {
    weaponImages[x][0] = loadImage("resources/sprites/weapons/"+x+".PNG");
    weaponImages[x][0].loadPixels();
    for (int z = 0; z < weaponImages[x][0].pixels.length; z++)
    {
      if (z == WHITE)
        z = color(254, 254, 254);
    }
    weaponImages[x][0].updatePixels();
    for (int y = 0; y < 16; y++)
    {
      weaponImages[x][y] = rotateImage(weaponImages[x][0], 1-(y/16.0f));
      weaponImages[x][y].loadPixels();
    }
  }
  for (int x = 0; x < 12; x++)
  {
    projectileImages[x][0] = loadImage("resources/sprites/projectiles/"+x+".PNG"); 
    for (int y = 0; y < 16; y++)
    {
      if (y > 0)
        projectileImages[x][y] = rotateImage(projectileImages[x][0], 1-(y/16.0f)); 
      projectileImages[x][y].loadPixels();
    }
  }
  for (int x = 0; x < 12; x++)
  {
    explosion[x] = loadImage("resources/sprites/BOOM/"+x+".PNG"); 
    explosion[x].loadPixels();
  }
  for (int x = 0; x < 10; x++)
  {
    numbers[x] = loadImage("resources/sprites/numbers/"+x+".PNG"); 
    numbers[x].loadPixels();
  }
  descriptions[0] = new PImage(0, 0); 
  descriptions[0].loadPixels(); 

  cancelBuy = loadImage("resources/UIcomponents/descriptions/cancelBuy.PNG"); 
  cancelBuy.loadPixels(); 
  fieldZones = loadImage("resources/zones.PNG"); 
  fieldZones.loadPixels(); 
  POPimg = loadImage("resources/sprites/BOOM/POP.PNG"); 
  POPimg.loadPixels(); 
  BOMB = loadImage("resources/sprites/projectiles/bomb.PNG"); 
  BOMB.loadPixels(); 
  BIG_BOMB = loadImage("resources/sprites/projectiles/big_bomb.PNG"); 
  BIG_BOMB.loadPixels(); 
  OBSTACLE = loadImage("resources/sprites/projectiles/obstacle.PNG"); 
  OBSTACLE.loadPixels(); 
  TACK_POP = loadImage("resources/sprites/projectiles/tack.PNG"); 
  TACK_POP.loadPixels(); 
  spritesLoaded = true;
  BLOONZ = loadStrings("resources/BLOONZ.TXT");
  POP_ALL = loadImage("resources/sprites/bloons/POP_ALL.PNG");
  for (int x = 0; x < BLOONZ.length; x++)
  {
    for (int y = 0; y < BLOONZ[x].length (); y++)
    {
      bloonArray[x][y] = getBloonTypeFromChar(BLOONZ[x].charAt(y));
    }
  }
  messages = loadStrings("resources/LEVELS.TXT");
}
public int getBloonTypeFromChar(char BTIN)
{
  if (BTIN == '0')
    return 0;
  if (BTIN == '1')
    return 1;
  if (BTIN == '2')
    return 2;
  if (BTIN == '3')
    return 3;
  if (BTIN == '4')
    return 4;
  if (BTIN == '5')
    return 5;
  if (BTIN == '6')
    return 6;
  if (BTIN == '7')
    return 7;
  if (BTIN == '8')
    return 8;
  if (BTIN == '9')
    return 9;
  if (BTIN == 'A')
    return 10;
  if (BTIN == 'B')
    return 11;
  if (BTIN == 'C')
    return 12;
  if (BTIN == 'D')
    return 13;
  if (BTIN == 'E')
    return 14;
  if (BTIN == 'F')
    return 15;
  if (BTIN == 'G')
    return 16;
  return 69;
}
public PImage rotateImage(PImage imageIn, float Ramt)
{
  imageOut = createImage(max(imageIn.width+1, imageIn.height+1), max(imageIn.width+1, imageIn.height+1), ARGB);
  imageOut.loadPixels();
  for (int x = 0; x < imageOut.pixels.length; x++)
    imageOut.pixels[x] = BLACK;
  Ramt = Ramt * TWO_PI;
  imageIn.loadPixels(); 
  for (int x = 0; x < imageIn.width; x++) 
  {
    int hwidth = imageIn.width / 2;
    int hheight = imageIn.height / 2;
    int xt = x - hwidth;
    for (int y = 0; y < imageIn.height; y++) 
    {
      int yt = y - hheight;
      float sinma = sin(-Ramt);
      float cosma = cos(-Ramt);

      int xs = (int)round((cosma * xt - sinma * yt) + hwidth);
      int ys = (int)round((sinma * xt + cosma * yt) + hheight);

      if (xs >= 0 && xs < imageIn.width && ys >= 0 && ys < imageIn.height) {
        /* set target pixel (x,y) to color at (xs,ys) */
        imageOut.pixels[x*imageOut.width+y] = imageIn.pixels[xs*imageIn.width+ys];
      } else if (x >= 0 && x < imageOut.width && y >= 0 && y < imageOut.height) {
        imageOut.pixels[x*imageOut.width+y] = BLACK;
      }
    }
  }
  imageOut.updatePixels();
  return imageOut;
}
public void preloader()
{
  progress = 0;
  delay(200);
  for (int x = 0; x < 700000; x++)
    weaponPixels[x] = -1;
  bloons = new Bloon[8192];
  progress = 10;
  delay(200);
  for (int x = 0; x < 696969; x++)
  {
    randumb[x] = (int)random(101);
  }
  playField = loadImage("resources/playfield.PNG");
  progress = 20;
  delay(200);
  for (int x = 0; x < 8192; x++)
    POP[x] = new Pop();
  progress = 30;
  delay(200);
  initializeBloons();
  progress = 40;
  delay(200);
  initializeProjectiles();
  progress = 50;
  delay(200);
  initializeWeapons();
  progress = 60;
  delay(200);
  frame.setTitle("Bloons Tower Defense");
  textSize(20);
  delay(200);
  progress = 70;
  delay(200);
  loadSprites();
  progress = 80;
  delay(200);
  progress = 90;
  delay(200);
  loadPixels();
  progress = 100;
  delay(200);
  loaded = true;
}
public void delay(int in_x)
{
  try {
    Thread.sleep(in_x);
  }
  catch(Exception e)
  {
  }
}

/* spawnBloonChildren is:
 when a bloon is hit: pop it, spawn children and set a POP icon
 move weapon bullets according to their velocities
 */
public void spawnBloonChildren()
{
  //-----------------------------------------------------------------Begin updating spawnBloonChildren
  for (int x = 0; x < 8192; x++)
  {
    if (bloons[x].type != 0)
    {
      if (bloons[x].damage > damageThreshold[bloons[x].type])
      {
        BT = bloons[x].type; ////////////////////////////////////////  remember: y is not for loopsn here
          bloons[x].gluey = false;
        if (BT == RED_BLOON)
          bloons[x].type = 0;
        if (BT == BLUE_BLOON)
          bloons[x].type = RED_BLOON;
        if (BT == GREEN_BLOON)
          bloons[x].type = BLUE_BLOON;
        if (BT == YELLOW_BLOON)
          bloons[x].type = GREEN_BLOON;
        if (BT == PINK_BLOON)
          bloons[x].type = YELLOW_BLOON;
        if (BT == WHITE_BLOON || BT == BLACK_BLOON)
        {
          bloons[x].type = YELLOW_BLOON;
          spawnBloonChild(YELLOW_BLOON, bloons[x].step-64);
        }
        if (BT == ZEBRA_BLOON)
        {
          bloons[x].type = PINK_BLOON;
          spawnBloonChild(PINK_BLOON, bloons[x].step-64);
        }
        if (BT == CAMO_BLOON)
        {
          bloons[x].type = PINK_BLOON;
          spawnBloonChild(PINK_BLOON, bloons[x].step-64);
        }
        if (BT == RAINBOW_BLOON)
        {
          bloons[x].type = BLACK_BLOON;
          spawnBloonChild(BLACK_BLOON, bloons[x].step-13);
          spawnBloonChild(WHITE_BLOON, bloons[x].step-28);
          spawnBloonChild(WHITE_BLOON, bloons[x].step-55);
        }
        if (BT == CERAMIC_BLOON)
        {
          bloons[x].type = RAINBOW_BLOON;
          spawnBloonChild(RAINBOW_BLOON, bloons[x].step-13);
        }
        bloons[x].damage = 0;


        POP[POPpointer].position = bloons[x].step;
        POP[POPpointer].timeToLive = 6;
        POPpointer++;
        if(POPpointer > 8191)
        POPpointer = 0;
      }
    }
  }

  //------------------------------------------------------------------End updating spawnBloonChildren
}
public void fixErrors()
{
  for(int x = 0; x < 8192; x++)
  {
    if(bloons[x].step > bloonPath.length)
    {
      bloons[x].step = 0;
      bloons[x].type = 0;
    }
  }
}
int DART = 1; // dart razor piercing
int TACK = 2; // tack shot
int BOOM = 3; // boom
int SUPERDART = 4;
int CANDY = 5;

class Projectile
{
  int xPos = 0;
  int yPos = 0;
  int xVel = 0;
  int yVel = 0;
  int type = 0;
  int step = 0;
  int level = 0;
  int damage = 0;
  int rotation = 0;
  Projectile(int Ix, int Iy, int IxVel, int IyVel, int Itype, int Ilevel)
  {
    xPos = Ix;
    yPos = Iy;
    xVel = IxVel;
    yVel = IyVel;
    type = Itype;
    step = 0;
    damage = 0;
    level = Ilevel;
    rotation = ((int)((atan2(yVel, xVel)+PI)*2.54f)+13)%16;
  }
}

public void spawnProjectile(int Ix, int Iy, int Ixv, int Iyv,int It, int Ilv)
{
  projectiles[projectilePointer] = new Projectile(Ix, Iy, Ixv, Iyv, It, Ilv);
  projectilePointer++;
  if (projectilePointer == 8191)
    projectilePointer = 0;
}
public void initializeProjectiles()
{
  for (int x = 0; x < 8192; x++)
  {
    projectiles[x] = new Projectile(0,0,0,0,0,0); // fill projectile field with blank projectiles
  }
}
public int getFiringType(int in_x, int in_y)
{
  if(in_x == DART)
  return 1;
  if(in_x == TACK)
  {
    if(in_y > 1)
    return 3;
    return 2;
  }
  if(in_x == BOOM)
  return 3;
  if(in_x == SUPERDART)
  {
  if(in_y == 2)
  return 5;
  if(in_y > 2)
  return 6;
  return 4;
  }
  return 1;
}


int TACK_SHOOTER = 1;
int BOOMERANG = 2;
int SPIKE_O_PULT = 3;
int ICE_TOWER = 4;
int MONKEY_BEACON = 5;
int SUPER_MONKEY = 6;
int MONKEY_GLUE = 7;
int PINEAPPLE = 8;
int CLASSIFIED = 9;
int DART_MONKEY = 10;
int ROAD_SPIKES = 11;
int CANNON = 12;
//841,206
class Weapon
{
  int type = 0;
  int xPos = 0;
  int yPos = 0;
  int step = 0;
  int lives = 1;
  int rotation = 0;
  int upgrade1 = 0;
  int upgrade2 = 0;
  Weapon(int It, int Ix, int Iy)
  {
    type = It;
    xPos = Ix;
    yPos = Iy;
    step = 0;
    rotation = 0;
    lives = 1;
  }
  public int range()
  {
    if(type == TACK_SHOOTER)
    return 85;
    if(type == SUPER_MONKEY)
    return 600;
    return 160;
  }
}

public void spawnWeapon(int Ix, int Iy, int It)
{
  temp = 0;
  weaponPointer++;
  if (weaponPointer == 999)
    weaponPointer = 0;
  while (weapons[weaponPointer].type != 0 && temp < 1000)
  {
    temp++;
    weaponPointer++;
    if (weaponPointer == 255)
      weaponPointer = 0;
  }
  weapons[weaponPointer] = new Weapon(It, Ix, Iy);
}
public void initializeWeapons()
{
  for (int x = 0; x < 1000; x++)
  {
    weapons[x] = new Weapon(0, 0, 0); // fill weapon field with blank weapons
  }
}


public void getHover()
{
  if (mousePressed)
    return;
  weaponHovered = 0;
  if (mouseX > 835 && mouseX < 990)
  {
    if (mouseY < 55)
    {
      if (mouseX < 890)
        weaponHovered = TACK_SHOOTER;
      else if (mouseX < 940)
        weaponHovered = BOOMERANG;
      else
        weaponHovered = SPIKE_O_PULT;
    } else if (mouseY < 102)
    {
      if (mouseX < 890)
        weaponHovered = ICE_TOWER;
      else if (mouseX < 940)
        weaponHovered = MONKEY_BEACON;
      else
        weaponHovered = SUPER_MONKEY;
    } else if (mouseY < 152)
    {
      if (mouseX < 890)
        weaponHovered = MONKEY_GLUE;
      else if (mouseX < 940)
        weaponHovered = PINEAPPLE;
      else
        weaponHovered = CLASSIFIED;
    } else if (mouseY < 200)
    {
      if (mouseX < 890)
        weaponHovered = DART_MONKEY;
      else if (mouseX < 940)
        weaponHovered = ROAD_SPIKES;
      else
        weaponHovered = CANNON;
    }
  }
}

public boolean weaponPlaceable(int Nx, int Nmx, int Nmy)
{
  if (Nmx+(1000*Nmy) > 699999)
    return false;

  if ((Nx == ROAD_SPIKES || Nx == MONKEY_GLUE || Nx == PINEAPPLE) && fieldZones.pixels[Nmx+(1000*Nmy)] == BLACK)
    return true;
  if (!(Nx == ROAD_SPIKES || Nx == MONKEY_GLUE || Nx == PINEAPPLE) && fieldZones.pixels[Nmx+(1000*Nmy)] == WHITE)
    return true;

  return false;
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "program" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
